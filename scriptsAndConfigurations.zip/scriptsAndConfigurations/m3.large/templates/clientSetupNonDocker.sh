#!/bin/bash

# This script downloads and sets up YCSB and starts the benchmark

echo "Client started, testing for port"

# before beginning, we need to make sure that the port 9042 is available on the SUT machine and Cassandra has started
while ! nc -z %INSERT_REMOTE_IP% 9042; do
  sleep 5 # wait for 1/10 of the second before check again
  echo "port not there"
done

cd ycsb-0.12.0

# load workload
sudo ./bin/ycsb load cassandra-cql -p hosts=%INSERT_REMOTE_IP% -P ../%INSERT_WORKLOAD% -s > ./workloada_load_res.txt

# run workload
sudo ./bin/ycsb run cassandra-cql -threads %INSERT_THREAD_COUNT% -p hosts=%INSERT_REMOTE_IP% -P ../%INSERT_WORKLOAD% -s  > ./../results.txt
