#!/bin/bash

# This script sets up the SUT in Docker and starts Cassandra. For details on the steps to install Cassandra, please refer to sutSetupNonDocker.sh

sudo service docker start
sudo usermod -a -G docker ec2-user

# the start.sh script will be run in the container on startup
# it reflects the steps of sutSetupNonDocker.sh
cat <<EOT >> ~/start.sh
#!/bin/bash

echo "installed cassandra, starting now..."

# sudo service cassandra start
echo -ne '\n\n\n' | cassandra -R

# sudo service cassandra start

# /usr/share/cassandra/bin/nodetool -h IP_ADDRESS info

echo "Cassandra started, testing for port"

ip addr show

ping %INSERT_PRIVATE_IP%

while ! nc -z %INSERT_PRIVATE_IP% 9042; do
  sleep 5 # wait for 1/10 of the second before check again
  echo "port not there"
done

cqlsh -f setup-ycsb.cql %INSERT_PRIVATE_IP% --cqlversion="3.4.4"

tail -f /dev/null

EOT

sudo chmod +x ./start.sh

sudo cat <<EOT >> setup-ycsb.cql
create keyspace ycsb
   WITH REPLICATION = {'class' : 'SimpleStrategy', 'replication_factor': 3 };
USE ycsb;
create table usertable (
   y_id varchar primary key,
  field0 varchar,
  field1 varchar,
  field2 varchar,
  field3 varchar,
  field4 varchar,
  field5 varchar,
  field6 varchar,
  field7 varchar,
  field8 varchar,
  field9 varchar) WITH COMPACTION = {%INSERT_COMPACTION_HERE%};
EOT


# create dockerfile
# 7199 - JMX (was 8080 pre Cassandra 0.8.xx)
# 7000 - Internode communication (not used if TLS enabled)
# 7001 - TLS Internode communication (used if TLS enabled)
# 9160 - Thrift client API
# 9042 - CQL native transport port
# the steps described here reflect the steps of sutSetupNonDocker.sh
cat <<EOT >> ~/Dockerfile
FROM hasenburg/docker-eval-sut:latest

COPY ./cassandra.yaml /etc/cassandra/conf/

COPY ./setup-ycsb.cql /setup-ycsb.cql

COPY ./start.sh /start.sh

EXPOSE 7000 7001 7199 9042 9160

CMD ["/bin/bash", "/start.sh"]

EOT

# build the SUT Docker container
sudo docker build -t sutdockercontainer .

# start the SUT Docker container and map the container's ports to the host's ports
sudo docker run -t -p 7000:7000 -p 7001:7001 -p 7199:7199 -p 9042:9042 -p 9160:9160 -d sutdockercontainer
