#!/bin/bash

# This script sets up the benchmarking client in Docker and runs the benchmark. For details on the steps to install YCSB, please refer to clientSetupNonDocker.sh

sudo service docker start
sudo usermod -a -G docker ec2-user

# the docker-entrypoint.sh script will be run when the Docker container is started and will generate a workload and start the benchmark
cat <<EOT >> ~/docker-entrypoint.sh
#!/bin/bash

echo "executing workload"

./ycsb-0.12.0/bin/ycsb load cassandra-cql -p hosts=%INSERT_REMOTE_IP% -P ./%INSERT_WORKLOAD%

echo "executing workload"

./ycsb-0.12.0/bin/ycsb run cassandra-cql -threads %INSERT_THREAD_COUNT% -p hosts=%INSERT_REMOTE_IP% -P ./%INSERT_WORKLOAD% -s  > /home/results.txt

ls -R /home/

EOT

chmod +x docker-entrypoint.sh

# the Dockerfile will be used to create the container image
# the steps in this Dockerfile reflect the steps in clientSetupNonDocker.sh
sudo cat <<EOT >> ~/Dockerfile
FROM hasenburg/docker-eval-client:latest

RUN tar xfvz ycsb-0.12.0.tar.gz

COPY ./%INSERT_WORKLOAD% /

COPY ./docker-entrypoint.sh /
CMD ["./docker-entrypoint.sh"]

EOT

# build the Docker container based on the Dockerfile
sudo docker build -t clientdockercontainer .

# start the Docker container
sudo docker run -t -P clientdockercontainer

container_id="$(sudo docker ps -q -l)"

# copy the results file from the Docker container
sudo docker cp $container_id:/home/results.txt ~/results.txt
