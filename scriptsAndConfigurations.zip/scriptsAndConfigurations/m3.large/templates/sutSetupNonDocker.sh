#!/bin/bash

# This script installs, sets up and starts Cassandra without using Docker.

# copy the cassandra.yaml into the configuration folder
sudo cp cassandra.yaml /etc/cassandra/conf/cassandra.yaml

echo "installed cassandra, starting now..."

# start the Cassandra service
(echo -ne '\n\n\n' | sudo cassandra -R) &

echo "Cassandra started, testing for port"

# wait for the Cassandra service to start by checking if port 9042 is available
while ! nc -z %INSERT_PRIVATE_IP% 9042; do
  sleep 5 # wait for 1/10 of the second before check again
  echo "port not there"
done


# create ycsb config file for cassandra
sudo cat <<EOT >> setup-ycsb.cql
create keyspace ycsb
   WITH REPLICATION = {'class' : 'SimpleStrategy', 'replication_factor': 3 };
USE ycsb;
create table usertable (
   y_id varchar primary key,
  field0 varchar,
  field1 varchar,
  field2 varchar,
  field3 varchar,
  field4 varchar,
  field5 varchar,
  field6 varchar,
  field7 varchar,
  field8 varchar,
  field9 varchar) WITH COMPACTION = {%INSERT_COMPACTION_HERE%};
EOT

# set up Cassandra for YCSB
sudo cqlsh -f setup-ycsb.cql %INSERT_PRIVATE_IP% --cqlversion="3.4.4"
