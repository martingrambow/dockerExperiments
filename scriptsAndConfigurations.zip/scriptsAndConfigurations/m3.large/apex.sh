#!/bin/bash

# This script runs the benchmarks as described in the thesis.
# Before this can be run, preparation.sh needs to be run.
#
# This script was used with bash on macOS 10.13, details for other environments may differ.

# set the directory for configuration files
directory=configurations

# move to the directory this script is run in in order to be able to use relative paths
parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

# I haven't been able to find another way of iterating over true and false
booleanValues=(true false)


# set name and path for benchmarking client configuration file
AWS_CLIENT_MACHINE_SETTINGS=./$directory/awsBenchSettings

# set name and path for SUT configuration file
AWS_SUT_MACHINE_SETTINGS=./$directory/awsSUTSettings

# set name and path for EC2 configuration for benchmarking client
AWS_CLIENT_EC2_TYPES=./$directory/awsClientTypes

# set name and path for EC2 configuration for SUT
AWS_SUT_EC2_TYPES=./$directory/awsSUTTypes

# set name and path for YCSB client thread count parameter values
YCSB_THREAD_CONFIGS=./$directory/ycsbThreadConfigs

# set name and path for YCSB workload parameter values
YCSB_WORKLOAD_CONFIGS=./$directory/ycsbWorkloadConfigs

# set name and path for Cassandra compaction settings parameter values
CASSANDRA_COMPACTION_SETTINGS=./$directory/cassandraCompactionSettings

# set name and path for Cassandra cache settings parameter values
CASSANDRA_CACHE_SETTINGS=./$directory/cassandraCacheSettings

# set name and path for template script with YCSB running in Docker
CLIENT_SETUP_DOCKER_SCRIPT=./templates/clientSetupDocker.sh

# set name and path for template script with YCSB running without Docker
CLIENT_SETUP_NONDOCKER_SCRIPT=./templates/clientSetupNonDocker.sh

# set name and path for template script for Cassandra running in Docker
SUT_SETUP_DOCKER_SCRIPT=./templates/sutSetupDocker.sh

# set name and path for template script for Cassandra running without Docker
SUT_SETUP_NONDOCKER_SCRIPT=./templates/sutSetupNonDocker.sh

# set name and path for template cassandra.yaml configuration file
DEFAULT_CASSANDRA_CONFIG=./templates/cassandra.yaml

# set name and path for template folder
DEFAULT_TEMPLATE_FOLDER=./templates/

# HELPER FUNCTIONS

# copies benchmark results from benchmarking client to local machine
#
# parameters:
#   $1 -> IP of client machine
#   $2 -> Path to put the results in
#
# returns:
#   results of benchmark
#
get_results() {
  # get keyname to use later
  keyname="$(sed '4q;d' $AWS_CLIENT_MACHINE_SETTINGS)"
  username="$(sed '5q;d' $AWS_CLIENT_MACHINE_SETTINGS)"

  # thanks to our script, the results will always be in a results.txt in the home directory of the benchmarking client machine
  # copy the results.txt from the benchmarking client to the local machine
  scp -i "$keyname.pem" $username@$1:results.txt ./$2
}


# sets up benchmarking client with setup script
#
# parameters:
#   $1 -> IP of client machine
#   $2 -> path to client.sh
#   $3 -> path to workload file
#
# returns:
#   nothing
#
setup_client() {
  # get keyname to use later
  keyname="$(sed '4q;d' $AWS_CLIENT_MACHINE_SETTINGS)"
  username="$(sed '5q;d' $AWS_CLIENT_MACHINE_SETTINGS)"

  # get workload name
  workloadname=$(echo $3 | sed 's/.*\///')

  # copy workload file to client machine
  scp -i "$keyname.pem" $3 $username@$1:$workloadname #&> /dev/null

  # run modified client.sh on benchmarking client
  ssh -i "$keyname.pem" $username@$1 'bash -s' < $2 #&> /dev/null

}

# sets up SUT with cassandra.yaml and setup script
#
# parameters:
#   $1 -> IP of SUT machine
#   $2 -> path to sut.sh
#   $3 -> path to cassandra.yaml
#
# returns:
#   nothing
#
setup_sut() {
  # get keyname to use later
  keyname="$(sed '4q;d' $AWS_SUT_MACHINE_SETTINGS)"
  username="$(sed '5q;d' $AWS_CLIENT_MACHINE_SETTINGS)"

  # copy modified cassandra.yaml to SUT machine
  scp -i "$keyname.pem" $3 $username@$1:./cassandra.yaml #&> /dev/null

  # run modified sut.sh on SUT machine
  ssh -i "$keyname.pem" $username@$1 'bash -s' < $2 #&> /dev/null

}

# creates an AWS EC2 instance
#
# parameters:
#   $1 -> aws settings file to use
#   $2 -> aws ec2 instance type
#   $3 -> index of amazon AMI in file
#
# returns:
#   instance id for the created machine
#
create_aws_machine() {
  # read instance configuration
  imageLine="$(sed '2q;d' $1)"
  imageArray=($imageLine)

  image_id=${imageArray[$3]}


  security_group="$(sed '3q;d' $1)"
  instance_type=$2
  keyname="$(sed '4q;d' $1)"
  username="$(sed '5q;d' $1)"

  # create instance and save instance id for later use
  instance_id="$(aws ec2 run-instances --image-id $image_id --security-group-ids $security_group --count 1 --instance-type $instance_type --key-name $keyname --monitoring Enabled=false --query 'Instances[0].InstanceId' --placement 'AvailabilityZone=eu-west-1b')"

  (>&2 echo $instance_id)

  instance_state="$(aws ec2 describe-instance-status --instance-ids $instance_id --output text --query InstanceStatuses[0].InstanceState.Code)"

  (>&2 echo $instance_id)

  until [ $instance_state = 16 ]; do
    sleep 1s
    instance_state="$(aws ec2 describe-instance-status --instance-ids $instance_id --output text --query InstanceStatuses[0].InstanceState.Code)"
  done

  (>&2 echo $instance_id)

  # while we're at it, update the machine
  machine_ip="$(aws ec2 describe-instances --instance-ids $instance_id --query 'Reservations[0].Instances[0].PublicIpAddress')"

  (>&2 echo $instance_id)

  # ports are open a bit after the machine has booted

  (while ! nc -z $machine_ip 22; do
    sleep 0.1 # wait for 1/10 of the second before check again
  done) &> /dev/null

  (>&2 echo $instance_id)

  # before we can ssh into the machine we need to accept the host public key

  (ssh-keyscan $machine_ip >> ~/.ssh/known_hosts)

  # ssh into the machine and execute a yum update to update all packages
  # ssh -i "$keyname.pem" $username@$machine_ip 'sudo yum -y update' &> /dev/null

  (>&2 echo $instance_id)

  echo $instance_id

  (>&2 echo $instance_id)

}


# runs a benchmark
#
# parameters:
#   $1 -> should YCSB be dockerized (true/false)
#   $2 -> should Cassandra be dockerized (true/false)
#   $3 -> YCSB No. of threads to use
#   $4 -> YCSB workload to use
#   $5 -> Cassandra compaction strategy to use
#   $6 -> Cassandra cache size to use
#   $7 -> AWS EC2 instance type for client
#   $8 -> AWS EC2 instance type for SUT
#   $9 -> the current run
#
# returns:
#   information about the running benchmark
#
benchmark() {
  #Lock Testcase by creating temporary folder
  mkdir temporary/$1_$2_$3_$4_$5_$6_$7_$8_$9 #&> /dev/null

  #set index
  indexSut=-1
  indexClient=-1

  if $1; then
    # the client should run Docker
    indexClient=0;
  else
    # the client should not run Docker
    indexClient=1;
  fi

  if $2; then
    # the sut should run Docker
    indexSut=2
  else
    # the sut should not run Docker
    indexSut=3
  fi

  # create bechmarking client machine
  client_id="$(create_aws_machine $AWS_CLIENT_MACHINE_SETTINGS $7 $indexClient)"
  (>&2 echo $client_id)
  echo "Client machine created, aws ID is $client_id"

  # tag it to find it in the AWS dashboard later
  aws ec2 create-tags --resources $client_id --tags Key=Name,Value=client$1$2

  # extract the benchmarking client machine's public IP address
  client_machine_ip="$(aws ec2 describe-instances --instance-ids $client_id --query 'Reservations[0].Instances[0].PublicIpAddress')"

  # create SUT machine
  sut_id="$(create_aws_machine $AWS_SUT_MACHINE_SETTINGS $8 $indexSut)"
  echo "SUT machine created, aws ID is $sut_id"

  # tag it to find it in the AWS dashboard later
  aws ec2 create-tags --resources $sut_id --tags Key=Name,Value=sut$1$2

  # extract the SUT machine's public IP address
  sut_machine_ip="$(aws ec2 describe-instances --instance-ids $sut_id --query 'Reservations[0].Instances[0].PublicIpAddress')"

  # extract the SUT machine's private IP address
  sut_machine_private_ip="$(aws ec2 describe-instances --instance-ids $sut_id --query 'Reservations[0].Instances[0].PrivateIpAddress')"

  # create the setup scripts by placing values in temporary files

  # step 1: copy needed files to temporary folder into specific subfolder
  #mkdir already done to lock testCase
  #mkdir temporary/$1_$2_$3_$4_$5_$6_$7_$8_$9 &> /dev/null
  specific_path=./temporary/$1_$2_$3_$4_$5_$6_$7_$8_$9 #&> /dev/null

  cp $DEFAULT_CASSANDRA_CONFIG $specific_path/cassandra.yaml #&> /dev/null

  # copy workload file
  cp $DEFAULT_TEMPLATE_FOLDER/$4 $specific_path/$4

  # save ids of aws machines


  if $1; then
    # the client should run Docker
    echo "running docker for client" #&> /dev/null
    cp $CLIENT_SETUP_DOCKER_SCRIPT $specific_path/client.sh
  else
    # the client should not run Docker
    echo "not running docker for client" #&> /dev/null
    cp $CLIENT_SETUP_NONDOCKER_SCRIPT $specific_path/client.sh
  fi

  if $2; then
    # the sut should run Docker
    echo "running docker for sut" #&> /dev/null
    cp $SUT_SETUP_DOCKER_SCRIPT $specific_path/sut.sh #&> /dev/null

    # Cassandra needs to know how it can reach itself via IP
    # use the Docker containers internal IP for cassandra
    sed -i -e "s/%INSERT_PRIVATE_IP%/172.17.0.2/g" $specific_path/cassandra.yaml

    sed -i -e "s/%INSERT_PRIVATE_IP%/172.17.0.2/g" $specific_path/sut.sh
  else
    # the sut should not run Docker
    echo "not running docker for sut" #&> /dev/null
    cp $SUT_SETUP_NONDOCKER_SCRIPT $specific_path/sut.sh #&> /dev/null

    # Cassandra needs to know how it can reach itself via IP
    # use the SUTs private IP for cassandra
    sed -i -e "s/%INSERT_PRIVATE_IP%/$sut_machine_private_ip/g" $specific_path/cassandra.yaml

    sed -i -e "s/%INSERT_PRIVATE_IP%/$sut_machine_private_ip/g" $specific_path/sut.sh
  fi

  # step 2: place in all the parameters
  # $3 -> YCSB No. of threads to use
  sed -i -e "s/%INSERT_THREAD_COUNT%/$3/g" $specific_path/client.sh

  # $4 -> YCSB workload to use
  sed -i -e "s/%INSERT_WORKLOAD%/$4/g" $specific_path/client.sh

  # $5 -> Cassandra compaction strategy to use
  sed -i -e "s/%INSERT_COMPACTION_HERE%/$5/g" $specific_path/sut.sh

  # $6 -> Cassandra cache size to use
  # to use the "auto" value, this space needs to be kept blank in cassandra.yaml
  if [ "$6" == "auto" ]; then
    sed -i -e "s/%INSERT_CACHE_HERE%//g" $specific_path/cassandra.yaml
  else
    sed -i -e "s/%INSERT_CACHE_HERE%/$6/g" $specific_path/cassandra.yaml
  fi

  # insert the public IP of the SUT machine into the setup script for the benchmarking client
  sed -i -e "s/%INSERT_REMOTE_IP%/$sut_machine_ip/g" $specific_path/client.sh


  # set up SUT
  # send everything concerning Cassandra
  setup_sut $sut_machine_ip $specific_path/sut.sh $specific_path/cassandra.yaml #&> /dev/null

  # set up benchmarking client
  # send everything concerning YCSB
  # benchmark will start automatically
  setup_client $client_machine_ip $specific_path/client.sh $specific_path/$4 #&> /dev/null

  # ouput results
  get_results $client_machine_ip "results/results-$1_$2_$3_$4_$5_$6_$7_$8_$9.txt"

  # terminate machines
  aws ec2 terminate-instances --instance-ids $client_id #&> /dev/null
  aws ec2 terminate-instances --instance-ids $sut_id #&> /dev/null


}

# creates a filename for a result with the given parameters
# this is currently used to skip results that have already been completed, located in an "oldresults" directory
#
# parameters:
#   $1 -> should YCSB be dockerized (true/false)
#   $2 -> should Cassandra be dockerized (true/false)
#   $3 -> YCSB No. of threads to use
#   $4 -> YCSB workload to use
#   $5 -> Cassandra compaction strategy to use
#   $6 -> Cassandra cache size to use
#   $7 -> AWS EC2 instance type for client
#   $8 -> AWS EC2 instance type for SUT
#   $9 -> the current run
#
# returns:
#   path to oldresults
#
get_filename() {
  echo "results/results-$1_$2_$3_$4_$5_$6_$7_$8_$9.txt"
}

# generates the temporary folder name for a test case
#
# parameters:
#   $1 -> should YCSB be dockerized (true/false)
#   $2 -> should Cassandra be dockerized (true/false)
#   $3 -> YCSB No. of threads to use
#   $4 -> YCSB workload to use
#   $5 -> Cassandra compaction strategy to use
#   $6 -> Cassandra cache size to use
#   $7 -> AWS EC2 instance type for client
#   $8 -> AWS EC2 instance type for SUT
#   $9 -> the current run
#
# returns:
#   path to tempoary folder of test case
#
get_TmpFolderName() {
  echo "temporary/$1_$2_$3_$4_$5_$6_$7_$8_$9"
}

# create directories for results and temporary files
mkdir temporary
mkdir results

# MAIN LOGIC
# each experiment will need to be repeated five times in total
for run in 1 2 3 4 5; do
  # iterate over possible settings for No of threads in YCSB
  while read ycsb_no_of_threads; do
    # iterate over possible settings for workloads in YCSB
    while read ycsb_workload; do
      # iterate over possible settings for compaction strategies in Cassandra
      while read cassandra_compaction_strategy; do
        # iterate over possible settings for cache settings in Cassandra
        while read cassandra_cache_setting; do
          # iterate over possible settings for benchmarking client EC2 type
          while read aws_client_type; do
            # iterate over possible settings for SUTEC2 type
            while read aws_sut_type; do
              # iterate over true/false for "ycsb_dockerized"
              for ycsb_dockerized in "${booleanValues[@]}"; do
                # iterate over true/false for "cassandra_dockerized"
                for cassandra_dockerized in "${booleanValues[@]}"; do

                  # generate a filename for the results of this benchmark in the folder "oldresult"
                  filename=$(get_filename $ycsb_dockerized $cassandra_dockerized $ycsb_no_of_threads $ycsb_workload $cassandra_compaction_strategy $cassandra_cache_setting $aws_client_type $aws_sut_type $run)

                  foldername=$(get_TmpFolderName $ycsb_dockerized $cassandra_dockerized $ycsb_no_of_threads $ycsb_workload $cassandra_compaction_strategy $cassandra_cache_setting $aws_client_type $aws_sut_type $run)

                  # only execute the benchmark, if it has not yet run
                  if [ ! -f $filename ]; then
                    # only execute the benchmark, if it's not running currently
                    if [ ! -d $foldername ]; then
                      echo "---------------------------------------------"
                      echo "YCSB Dockerized: $ycsb_dockerized"
                      echo "Cassandra Dockerized: $cassandra_dockerized"
                      echo "YCSB No of Threads: $ycsb_no_of_threads"
                      echo "YCSB Workload: $ycsb_workload"
                      echo "Cassandra Compaction Strategy: $cassandra_compaction_strategy"
                      echo "Cassandra Cache Size: $cassandra_cache_setting"
                      echo "Run $run"
                      # execute the benchmark
                      benchmark $ycsb_dockerized $cassandra_dockerized $ycsb_no_of_threads $ycsb_workload $cassandra_compaction_strategy $cassandra_cache_setting $aws_client_type $aws_sut_type $run
                    else
                      echo "Test $foldername currently running, skip it"
                    fi
                  else
                    echo "Test $filename already tested, skip it!"
                  fi
                done
              done
            done < $AWS_CLIENT_EC2_TYPES
          done < $AWS_CLIENT_EC2_TYPES
        done < $CASSANDRA_CACHE_SETTINGS
      done < $CASSANDRA_COMPACTION_SETTINGS
    done < $YCSB_WORKLOAD_CONFIGS
  done < $YCSB_THREAD_CONFIGS
done
