#!/bin/bash

# This script undos all changes made in preparation.sh to reset the benchmark environment.
# The following tasks are performed:
# - security groups for benchmarking client and SUT are deleted
# - key pairs for the benchmarking client and SUT are delete
# - private keys are removed
#
# This script was used with bash on macOS 10.13, details for other environments may differ.

# set the directory for configuration files
directory=configurations

# move to the directory this script is run in in order to be able to use relative paths
parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

# set name and path for SUT configuration file
AWS_SUT_MACHINE_SETTINGS=./$directory/awsSUTSettings

# set name and path for benchmarking client configuration file
AWS_CLIENT_MACHINE_SETTINGS=./$directory/awsBenchSettings

# read configuration for SUT and benchmarking client from configuration files
sut_security_group="$(sed '3q;d' $AWS_SUT_MACHINE_SETTINGS)"
sut_keyname="$(sed '4q;d' $AWS_SUT_MACHINE_SETTINGS)"

client_security_group="$(sed '3q;d' $AWS_CLIENT_MACHINE_SETTINGS)"
client_keyname="$(sed '4q;d' $AWS_CLIENT_MACHINE_SETTINGS)"

# delete security groups
aws ec2 delete-security-group --group-name $sut_security_group

aws ec2 delete-security-group --group-name $client_security_group

# remove key pairs
aws ec2 delete-key-pair --key-name $sut_keyname

aws ec2 delete-key-pair --key-name $client_keyname

# delete private key files
rm $client_keyname.pem
rm $sut_keyname.pem
