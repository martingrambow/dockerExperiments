#!/bin/bash

# This scripts starts the given number of screen seesions with the apex file.
# parameters:
#   $1 -> number of to be started session

LOGSDIR=masterscreenlogs

echo "Removing old logs"
rm -r $LOGSDIR
mkdir $LOGSDIR

# first, kill all screen sessions
echo "Stopping these screen sessions:"
screen -ls | grep "eval-session" | awk '{ print $1; }'
screen -ls | grep "eval-session" | awk '{ print $1; }' | cut -d'.' -f1 | xargs -I {} -n 1 screen -S {} -X quit

if [ ! -z "$1" ]; then

  for sessionNum in $(seq 1 $1); do
    cp ~/.screenrc $LOGSDIR/screenconfig$sessionNum
    echo "logfile masterscreenlogs/screenlog$sessionNum.log" >> $LOGSDIR/screenconfig$sessionNum

    echo "Starting screen eval-session $sessionNum"
    screen -c $LOGSDIR/screenconfig$sessionNum -dmS eval-session$sessionNum -L ./apex.sh

    sleep 5s
  done

fi
