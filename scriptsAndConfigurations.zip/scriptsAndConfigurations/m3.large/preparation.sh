#!/bin/bash

# This script prepares an environment for the benchmarks to run in.
# The following tasks are performed:
# - the AWS CLI is installed/updated
# - configuration like keys are read from the configuration files and installed to the AWS CLI
# - security groups for benchmarking client and SUT are created
# - key pairs for the benchmarking client and SUT are created
# - the private keys are saved in files for later use and their permissions are changed to comply with ssh requirements
#
# This script was used with bash on macOS 10.13, details for other environments may differ.

# set the directory for configuration files
directory=configurations


# move to the directory this script is run in in order to be able to use relative paths
parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

# set the name and path of the AWS CLI configuration file
AWS_CLI_CONFIG_FILE=./$directory/awsclisettings

# Install the AWS CLI (or upgrade it if it is already installed)
# --ignore-installed six because of https://github.com/pypa/pip/issues/3165
sudo -H pip install --ignore-installed six awscli --upgrade

# read AWS CLI configuration from configuration file
AWS_ACCESS_KEY="$(sed '1q;d' $AWS_CLI_CONFIG_FILE)"
AWS_SECRETACCESS_KEY="$(sed '2q;d' $AWS_CLI_CONFIG_FILE)"
AWS_REGION="$(sed '3q;d' $AWS_CLI_CONFIG_FILE)"
AWS_OUTPUT_FORMAT="$(sed '4q;d' $AWS_CLI_CONFIG_FILE)"


# configure the AWS CLI according to our configuration parameters
aws configure set aws_access_key_id $AWS_ACCESS_KEY
aws configure set aws_secret_access_key $AWS_SECRETACCESS_KEY
aws configure set region $AWS_REGION
aws configure set output $AWS_OUTPUT_FORMAT


# set name and path for SUT configuration file
AWS_SUT_MACHINE_SETTINGS=./$directory/awsSUTSettings

# set name and path for benchmarking client configuration file
AWS_CLIENT_MACHINE_SETTINGS=./$directory/awsBenchSettings

# read configuration for SUT and benchmarking client from configuration files
sut_security_group="$(sed '3q;d' $AWS_SUT_MACHINE_SETTINGS)"
sut_keyname="$(sed '4q;d' $AWS_SUT_MACHINE_SETTINGS)"

client_security_group="$(sed '3q;d' $AWS_CLIENT_MACHINE_SETTINGS)"
client_keyname="$(sed '4q;d' $AWS_CLIENT_MACHINE_SETTINGS)"

# create necessary security groups
aws ec2 create-security-group --group-name $sut_security_group --description "Security Group for Benchmark SUTs"

aws ec2 create-security-group --group-name $client_security_group --description "Security Group for Benchmarking Clients"

# confgure client security group
# only SSH (22) is necessary for incomming connections
aws ec2 authorize-security-group-ingress --group-name $client_security_group --protocol tcp --port 22 --cidr 0.0.0.0/0

# confgure client security group
# ports need to be enabled for SSH (22) and Cassandra:
# 7199 - JMX (was 8080 pre Cassandra 0.8.xx)
# 7000 - Internode communication (not used if TLS enabled)
# 7001 - TLS Internode communication (used if TLS enabled)
# 9160 - Thrift client API
# 9042 - CQL native transport port
# (see https://stackoverflow.com/questions/2359159/cassandra-port-usage-how-are-the-ports-used)
aws ec2 authorize-security-group-ingress --group-name $sut_security_group --protocol tcp --port 22 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-name $sut_security_group --protocol tcp --port 7199 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-name $sut_security_group --protocol tcp --port 7000 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-name $sut_security_group --protocol tcp --port 7001 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-name $sut_security_group --protocol tcp --port 9160 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-name $sut_security_group --protocol tcp --port 9042 --cidr 0.0.0.0/0

# create key pairs to connect to the instances
aws ec2 create-key-pair --key-name $client_keyname --query 'KeyMaterial' --output text > $client_keyname.pem

aws ec2 create-key-pair --key-name $sut_keyname --query 'KeyMaterial' --output text > $sut_keyname.pem

# set permissions for private key files to 400 as required by ssh
chmod 400 $client_keyname.pem
chmod 400 $sut_keyname.pem
